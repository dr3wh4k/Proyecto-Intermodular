# Proyecto Intermodular de ASIR: CyberNova

**Proyecto:** Diseño del sistema informático empresarial de CyberNova  
**Ciclo:** Administración de Sistemas Informáticos en Red (ASIR)

## Integrantes
- José Miguel López Mora
- Raúl Alfaro Mora
- Asier Linares Morales
- Andreu Sánchez
- Izan Rubio España

## Descripción
CyberNova es una empresa de informática y ciberseguridad que ofrece análisis forense digital, auditorías de seguridad, pentesting, formación y análisis de datos para detectar amenazas.

El proyecto consiste en diseñar una infraestructura informática segura, organizada y ampliable para sus cuatro sedes en España: **Alcoi (sede central), Barcelona, Madrid y Vigo**.

## Estructura del repositorio

```text
CyberNova-ASIR/
├── README.md
├── .gitignore
├── documentacion/
│   ├── A1-analisis-empresa.md
│   ├── A2-necesidades-servicios.md
│   └── A3-propuesta-infraestructura.md
├── bitacora/
│   └── registro-trabajo.md
└── recursos/
    └── README.md
```

## Requisitos principales del escenario
- Cuatro sedes: Alcoi, Barcelona, Madrid y Vigo.
- Dos edificios por sede, con las zonas de trabajo indicadas en la documentación.
- Tres servidores físicos y seis servidores virtuales por CPD.
- Comunicación entre sedes mediante redes privadas y direccionamiento IP privado.
- Separación de los servicios en zona pública, extranet e intranet.

## Estado del proyecto
La documentación de A1, A2 y A3 recoge el análisis y la propuesta general inicial. La selección definitiva de equipos, el direccionamiento IP, las configuraciones y la implantación se concretarán en las siguientes fases.

## Cómo colaborar
1. Crear una rama para los cambios, si el grupo lo considera necesario.
2. Usar nombres claros para archivos y carpetas.
3. Actualizar la bitácora cuando se avance en el proyecto.
4. No subir contraseñas, claves privadas, datos personales reales ni configuraciones con secretos.
5. Añadir diagramas, scripts y configuraciones en `recursos/`, organizados por tema.
