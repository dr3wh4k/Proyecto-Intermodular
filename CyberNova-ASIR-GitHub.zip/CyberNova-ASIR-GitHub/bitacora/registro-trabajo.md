# Bitácora de trabajo

Registro de los avances realizados en el proyecto. Añadid una entrada cada vez que se realice un trabajo relevante.

| Fecha | Integrante(s) | Trabajo realizado | Archivos modificados | Pendiente / siguiente paso |
|---|---|---|---|---|
| AAAA-MM-DD | Nombre(s) | Crear la estructura inicial del repositorio y organizar la documentación A1, A2 y A3 | `README.md`, `documentacion/` | Revisar el contenido con el grupo y el profesor |
| | | | | |

## Recomendaciones
- Indicad lo que se ha hecho realmente; no dejéis entradas de ejemplo como si fueran trabajo completado.
- Anotad problemas encontrados y cómo se resolvieron.
- Cuando se añadan configuraciones, scripts o diagramas, indicad sus rutas.
