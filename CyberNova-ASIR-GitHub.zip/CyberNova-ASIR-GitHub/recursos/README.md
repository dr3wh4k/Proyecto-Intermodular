# Recursos del proyecto

Guardar aquí los materiales técnicos que se vayan creando durante el proyecto.

Estructura recomendada:
- `diagramas/`: topología de red, distribución de sedes, esquema de CPD y virtualización.
- `configuraciones/`: configuraciones de red y servicios, sin contraseñas ni secretos.
- `scripts/`: scripts de instalación, mantenimiento o comprobación.
- `capturas/`: capturas relevantes de pruebas y configuraciones.

Cread las subcarpetas cuando hagan falta. No subáis contraseñas, claves privadas, tokens ni datos reales de clientes.
